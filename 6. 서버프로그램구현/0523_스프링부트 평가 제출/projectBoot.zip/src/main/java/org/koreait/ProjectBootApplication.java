package org.koreait;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectBootApplication.class, args);
	}

}
