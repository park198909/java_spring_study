package org.koreait.models.board;

import lombok.Data;

@Data
public class BatchForm {
    private Long cnt;
    private String cTime;
}
