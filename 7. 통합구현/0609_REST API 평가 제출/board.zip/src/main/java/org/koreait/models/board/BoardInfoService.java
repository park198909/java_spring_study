package org.koreait.models.board;

import lombok.RequiredArgsConstructor;
import org.koreait.entities.BoardData;
import org.koreait.repositories.BoardDataRepository;
import org.springframework.stereotype.Service;

/**
 * 게시글 번호로 게시글 조회
 *
 */
@Service
@RequiredArgsConstructor
public class BoardInfoService {
    private final BoardDataRepository repository;

    public BoardData get(Long id) {

        BoardData data = repository.findById(id).orElseThrow(()->new BoardValidationException("게시글 조회에 실패했습니다."));
        return data;
    }
}
